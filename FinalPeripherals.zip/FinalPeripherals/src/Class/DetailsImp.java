/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Class;

/**
 *
 * @author Lhanz
 */
interface DetailsImp {
    
 public void _insert();
    
    public void _update();
    
    public void _delete();
    
    public void _LoadList();
    
    public void _getDetails(byte id);
    
    public void _search(String key);
    
    
    
}

